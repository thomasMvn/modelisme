<?php 
    $template = "templates/admin";
    include "layout.php"; 
?>
