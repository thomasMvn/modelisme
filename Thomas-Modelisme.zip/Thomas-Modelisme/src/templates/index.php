    <!-- Page d'accueil -->




</br>
    <!-- section featurette -->
<hr class="featurette-divider">
<div class="container  p-4 mt-5" >
    <div class="row featurette">
        <div class="col-md-7 order-md-2">
            <h2 class="featurette-heading">A propos<span class="text-muted"> de nous!</span></h2>
            <p class="lead font-weight-bold">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Delectus id eveniet quidem maxime corporis enim quam aliquam, inventore ab commodi quos voluptate ipsa voluptatum expedita quas quibusdam fugit minus modi! Lorem ipsum dolor sit amet consectetur adipisicing elit. Reprehenderit ut rerum aliquid modi exercitationem molestiae minima atque beatae, suscipit harum nobis pariatur iusto ipsum. Excepturi, magni dignissimos. Iste, animi. Aut?Lorem ipsum dolor, sit amet consectetur adipisicing elit. Possimus dolor, cum ut reprehenderit neque inventore ipsa vel et a mollitia minima aliquid quisquam, dolorem illum eius laborum repellat assumenda iusto!</p><br/>
        </div>
        <div class="col-md-5 order-md-1">
            <img src="images/theme/magasin.jpg" width="100%" height="100%" alt="blog">
        </div>
    </div>
</div>


<hr class="featurette-divider">