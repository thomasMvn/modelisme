<script type="text/javascript">

	//sample data
	
	var table = new Tabulator("#example-table", {
		 // set height of table to enable virtual  //load initial data into table
		pagination: "local", // active la pagination localement
		paginationSize : 15, // nombre de ligne sur la page, 10 par defaut
		layout:"fitColumns", 
		columns:[ //définir les colonnes
			{title:"Commande", field:"orderNumber", sorter:"number", width:150},
			{title:"Date de la commande", field:"orderDate", 
				sorter:"date", sorterParams:{
    				format:"YYYY-MM-DD", alignEmptyValues:"top",} },
			{title:"Date de la livraison", field:"shippedDate", 
				sorter:"date", sorterParams:{
   			format:"YYYY-MM-DD", alignEmptyValues:"top",} },
			{title:"Statut", field:"status", sorter:"string"},
		]

	});
var ajaxConfig = {
    method:"post", //set request type to Position
    headers: {
        "Content-type": 'application/json; charset=utf-8', //set specific content type
    },
};

table.setData("order.php", {}, ajaxConfig); //make ajax request with advanced config options
</script>