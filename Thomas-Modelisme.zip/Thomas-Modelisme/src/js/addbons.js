// fonction pour que la commande se valide et s'enregistre dans la BDD avec un boucle qui oblige la saissie de tous les champs 

function commande() {  
    if ($("#customerNumber").val() === "") {
        alert("Saisissez un client");
    } else if ($("#total").val() === "") {
        alert("Saisissez un produit");
    } else {
        $.ajax({
            url: "addBons.php",
            method: "POST",
            data: $("#formBons").serialize(),
            success: function(data){
                $('#reponseModal').modal('toggle');
                $("#formBons").trigger("reset");
            },
            error: function(jqXHR, textStatus, errorThrown) { //si il y a un error 
            console.log(textStatus, errorThrown);
            }
        })
    }    
} 