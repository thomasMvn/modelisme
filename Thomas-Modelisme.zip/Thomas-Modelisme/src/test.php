<?php $template = "templates/test";
include 'layout.php';