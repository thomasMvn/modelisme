<div id="example-table"></div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js"></script>
<link href="https://unpkg.com/tabulator-tables@4.7.1/dist/css/tabulator.min.css" rel="stylesheet">
<link href = "https://cdnjs.cloudflare.com/ajax/libs/tabulator/4.7.1/css/tabulator_midnight.min.css" rel = "stylesheet" >
<script type="text/javascript" src="https://unpkg.com/tabulator-tables@4.7.1/dist/js/tabulator.min.js"></script>
<script type = "text / javascript" src = "jquery.min.js" > </script> <script type = "text / javascript" src = "jquery-ui.min.js" > </script>
<script type="text/javascript">

	//sample data
	
	var table = new Tabulator("#example-table", {
		 // set height of table to enable virtual  //load initial data into table
		pagination: "local", // active la pagination localement
		paginationSize : 25, // nombre de ligne sur la page, 10 par defaut
		layout:"fitColumns", //fit columns to width of table (optional)
		columns:[ //Define Table Columns
			{title:"Commande", field:"orderNumber", sorter:"number",
			width:150, 
			cellClick:function(e, cell){
		var url = "order-form.php?orderNumber=";
    	var order = cell.getValue();
    	console.log(order);
    	var test = url+order;
    	console.log(test);
    	document.location.href=test;

    },
},
			{title:"Date de la commande", field:"orderDate", sorter:"date", sorterParams:{
    format:"YYYY-MM-DD",
    alignEmptyValues:"top",
}},
			{title:"Date de la livraison", field:"shippedDate", sorter:"date", sorterParams:{
    format:"YYYY-MM-DD",
    alignEmptyValues:"top",
}},
			{title:"Statut", field:"status", sorter:"string"},
		]

	});
var ajaxConfig = {
    method:"post", //set request type to Position
    headers: {
        "Content-type": 'application/json; charset=utf-8', //set specific content type
    },
};

table.setData("order.php", {}, ajaxConfig).then(function(){
	mybody = document.getElementsByTagName("body")[0];


}).catch(function(error){
    //handle error loading data
}); //make ajax request with advanced config options
</script>
