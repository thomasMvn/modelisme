<?php
    include "connect-bdd.php";

    $query = $pdo -> prepare 
        (
            "SELECT productName,
                    buyPrice,
                    quantityInStock
            FROM    products
            WHERE   productCode = ?"
        );

    $query -> execute([$_POST["productCode"]]);

    $dataProducts = $query->fetchAll(PDO::FETCH_ASSOC);

    //le retour doit être un JSON 
    //echo 'console.log('. json_encode( $dataProducts ) .')';
    echo json_encode($dataProducts);
    exit();
?>